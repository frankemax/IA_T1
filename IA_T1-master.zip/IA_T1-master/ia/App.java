package ia;

import java.io.FileNotFoundException;

public class App {

    public static void main(String[] args) throws FileNotFoundException {
        Genetico gen = new Genetico();

    }
}
