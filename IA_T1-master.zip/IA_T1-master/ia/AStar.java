package ia;

public class AStar {
}
